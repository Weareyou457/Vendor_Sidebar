const categories = ["Political", "Healthcare", "Education", "Bollywood"];
export default categories;
